package Assignment;

import java.util.Scanner;

public class Array {
	public static void main(String[] args) {
		int n, pos;
		Scanner s = new Scanner(System.in);
		System.out.println("Enter no. of elements you want in array:");
		n = s.nextInt();
		int a[] = new int[n + 1];
		System.out.println("Enter all the elements:");
		for (int i = 0; i < n; i++) {
			a[i] = s.nextInt();
		}

		for (int j = 0; j < n; j++) {
			//System.out.println(a[j] + ",");
			System.out.println("a[" + j + "] = " + a[j]);
		}

		System.out.println("Enter the position of the number which is to be deleted :");
		pos = s.nextInt();

		int i;
		for (int k = pos; k < n - 1; k++) {
			a[k] = a[k] + 1;
		}
		n = n - 1;

		System.out.println("\nOn deleting new array we get is\n");
		for (i = 0; i < n; i++) {
			System.out.println("a[" + i + "] = " + a[i]);
		}

		//System.out.println("Item 1 " + a[1]);

		int oldIndex = 0;
		int newIndex = (a.length - 1);
		if (oldIndex == newIndex)
			return;
		System.out.println(newIndex);
int e= a.length;
System.out.println(e);
		int c;
		for (c = e; c <0 ; c--) {
			a[c] = a[c] + 1;
			System.out.println("a[" + c + "] = " + a[c]);
		}
		System.out.println("***********************************************");
		int tmp = a[oldIndex];
		System.out.println(tmp);
		if (newIndex > oldIndex) {
			System.out.println(newIndex);
			System.out.println(oldIndex);
			a[oldIndex] = a[newIndex];
			a[newIndex] = tmp;
			System.out.println(newIndex);
			System.out.println(oldIndex);
		}
	}
}
